db: id5414279_bismit_fmipa
db_username: id5414279_root
db_password: qwerty
link git:
link: https://g64160115.000webhostapp.com/index.php/welcome/index
Sebuah CRUD yang dibuat untuk mempermudah para pembisnis di fmipa untuk saling berkolaborasi untuk mencapai tujuan bersama.